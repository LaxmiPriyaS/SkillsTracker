export class Chart {    
    public barChartData: any[];
    public barChartLabels: string[];
    public barChartType: string;
    public options: any;
    public chartColors: any[];
}
