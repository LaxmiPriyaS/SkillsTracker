import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import {ButtonsModule,ModalModule} from 'ngx-bootstrap';

import { RatingModule } from 'ngx-bootstrap';
import { ChartsModule } from 'ng2-charts';

import { AppComponent } from './app.component';
import { SkillsDashboardComponent } from './components/skills-dashboard/skills-dashboard.component';
import { AddEditAssociateComponent } from './components/add-edit-associate/add-edit-associate.component';
import { SkillsComponent } from './components/skills/skills.component';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import { SkillSearchPipe } from './components/pipe/skill-search.pipe';
import { SkillFilterPipe } from './components/pipe/skills-name-search.pipe';

import { HttpModule } from '@angular/http'

import {AssociateService} from './components/service/associate.service';
import { AssociateFilterPipe } from './components/pipe/associate-filter.pipe';

const appRoutes: Routes = [
  { path: 'skillsDashboard', component: SkillsDashboardComponent },  
  { path: 'EditAssociate/:id',component: AddEditAssociateComponent,data: { page: 'EditAssociate' } },
  { path: 'ViewAssociate/:id',component: AddEditAssociateComponent,data: { page: 'ViewAssociate' } },
  { path: 'AddAssociate', component: AddEditAssociateComponent,data: { page: 'AddAssociate' } },  
  { path: 'Skills', component: SkillsComponent },  
  { path: '', redirectTo: '/skillsDashboard', pathMatch: 'full' },  
  { path: '**', component: PageNotFoundComponent }
];

@NgModule({
  declarations: [
    AppComponent,
    SkillsDashboardComponent,
    AddEditAssociateComponent,
    SkillsComponent,
    PageNotFoundComponent,
    SkillSearchPipe,
	SkillFilterPipe,
    AssociateFilterPipe
  ],
  imports: [
    BrowserModule,ChartsModule,FormsModule, HttpModule,ButtonsModule.forRoot(),
    HttpClientModule, RatingModule.forRoot(),
	RouterModule.forRoot(appRoutes,{ enableTracing: true })
  ],
  providers: [AssociateService],
  bootstrap: [AppComponent]
})
export class AppModule { }
