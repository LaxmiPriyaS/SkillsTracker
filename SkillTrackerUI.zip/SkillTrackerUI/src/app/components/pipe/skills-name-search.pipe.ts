import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'skillFilter'
})
export class SkillFilterPipe implements PipeTransform {

transform(items:any[],skillSearch:string){
    if (items && items.length){
        
        return items.filter(item =>{
			if (skillSearch && item.skillName.toString().toLowerCase().indexOf(skillSearch) === -1){
                return false;
            }
           
            return true;
       })
    }
    else{
        return items;
    }
}
/*transform(items: any[], searchText: string): any {
		if(!items) return [];
		if(!searchText) return items;	
		searchText = searchText.toLowerCase();        	
		return items.filter( it => {
			console.log(it.associateName);
			return it.associateName.toLowerCase().includes(searchText);
		});
    }*/
}
